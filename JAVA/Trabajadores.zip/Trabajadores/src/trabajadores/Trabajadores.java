package trabajadores;

import java.util.Scanner;

public class Trabajadores {
    int trabajadores,dias;
    Scanner cap;
    Trabajadores()
    {
    cap=new Scanner(System.in);
    dias = 0;
    }//constructor
    
    void Generar_tiempo()
    {
        System.out.println("Ingrese la cantidad de trabajadores: ");
        trabajadores = cap.nextInt();
        dias = (189 * 150)/trabajadores;
        System.out.println("se demoran: "+ dias);
    }
    
    

    public static void main(String[] args) {
        Trabajadores time=new Trabajadores();
        time.Generar_tiempo();
    }
    
}
