package taller;
/*
Calcule el valor que gana una persona por concepto de interés, teniendo en cuenta el monto de
la inversión y el porcentaje de interés.
*/

import java.util.Scanner;

public class punto11 {
    double inver, interes, valor;
    Scanner cap;
    
    punto11()
    {
        cap = new Scanner(System.in);
    
    }
    
    void inversion()
    {
        System.out.println("Ingrese el monto de su inversion: ");
        inver = cap.nextDouble();
        System.out.println("Ingrese el porcentaje de interes: ");
        interes = cap.nextInt();
        
        valor = (inver * interes) / 100;
        
        System.out.printf("El interes que usted gano es del: %.1f%n", valor);
    }
}


