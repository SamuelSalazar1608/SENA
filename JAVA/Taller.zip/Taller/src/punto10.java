package taller;
/*
Lea del teclado un número (real) de grados Fahrenheit y conviértalo a grados Celsius, mostrando
el resultado en la pantalla. La fórmula para la conversión es: Grados_Celsius = 5 / 9 x
(Grados_Fahrenheit ‐ 32)
*/

import java.util.Scanner;

public class punto10 {
    double fahrenheit, celsius;
    Scanner cap;
    
    punto10()
    {
        cap = new Scanner(System.in);
    }
    
    void conversion()
    {
        System.out.println("Ingrese los grados Fahrenheit: ");
        fahrenheit = cap.nextDouble();
        
        celsius = (5.0 / 9.0) * (fahrenheit - 32);
        
        System.out.printf("La conversion de Fahrenheit a Celsius es: %.1f C%n", celsius);
    }
}
