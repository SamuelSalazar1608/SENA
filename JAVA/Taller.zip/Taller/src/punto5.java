package taller;
//Intercambie los datos de dos variables que almacenan caracteres.

import java.util.Scanner;


public class punto5 {
    char a, b, temp;
    Scanner cap;
    
    punto5()
    {
        cap = new Scanner(System.in);
    }
    
    void intercambio()
    {
        System.out.println("Ingresa el caracter a");
        a = cap.next().charAt(0);
        System.out.println("Ingresa el caracter b");
        b = cap.next().charAt(0);
        temp = a;
        a = b;
        b = temp;
        System.out.println("Ahora a es " + a + "y b es " + b);
    }
}
