package taller;
//Calcule y muestre el área de un rectángulo.

import java.util.Scanner;

public class punto2 {
    int area,base,altura;
    Scanner cap;
    punto2()
    {
        cap=new Scanner(System.in);
        area=0;
    }
    void total()
    {
        System.out.println("Ingrese el valor de la base");
        base = cap.nextInt();
        System.out.println("Ingrese el valor de la altura");
        altura = cap.nextInt();
        area = (base*altura);
        System.out.println("el area del rectangulo es: "+ area);
    }
}
