package taller;
//Calcule el determinante de una matriz de dos filas y dos columnas.

import java.util.Scanner;

public class punto4 {
    double a, b, c, d, determinante;
    Scanner cap;
    
    punto4()
    {
        cap = new Scanner(System.in);
        determinante = 0;
    }
    
    void determinante()
    {
        System.out.println("Ingrese el valor de a: ");
        a = cap.nextDouble();
        System.out.println("Ingrese el valor de b: ");
        b = cap.nextDouble();
        System.out.println("Ingrese el valor de c: ");
        c = cap.nextDouble();
        System.out.println("Ingrese el valor de d: ");
        d = cap.nextDouble();
        determinante = (a * d) - (b * c);
        
        System.out.println("El determinante de la matriz es: " + determinante);
        
    }
}
