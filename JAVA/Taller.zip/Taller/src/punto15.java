package taller;
/*
Dado un número de dos cifras, obtener el número invertido. Ejemplo, si se introduce 15 que
muestre 51.
*/
import java.util.Scanner;


public class punto15 {
    int numero, decena, unidad, invertido;
    Scanner cap;
    
    punto15() {
        cap = new Scanner(System.in);
    }
    
    void invertir() {
        System.out.println("Ingrese un número de dos cifras: ");
        numero = cap.nextInt();
        
        decena = numero / 10;   
        unidad = numero % 10;   
        
        invertido = (unidad * 10) + decena;
        
        System.out.println("El número invertido es: " + invertido);
    }

}
