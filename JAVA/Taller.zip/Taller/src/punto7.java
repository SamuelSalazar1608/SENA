package taller;
//Calcule el volumen de un cono, la fórmula a emplear es: Volumen= (π * radio2 * altura)/3

import java.util.Scanner;


public class punto7 {
    double π, radio, altura, volumen;
    Scanner cap;
    
    punto7()
    {
        cap = new Scanner(System.in);
        π = 3.14;
    }
    
    void calculo_cono()
    {
        System.out.println("Ingrese el valor del radio: ");
        radio = cap.nextDouble();
        System.out.println("Ingrese el valor de la altura: ");
        altura = cap.nextDouble();
        
        volumen = (π * (radio * radio) * altura) / 3;
        
        System.out.printf("El volumen del cono es: %.1f%n", volumen);
    }
}
