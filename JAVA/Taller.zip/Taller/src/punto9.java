package taller;
//Calcule el perímetro de un rectángulo, conociendo la longitud de dos lados no paralelos. Perímetro= L1+ L2

import java.util.Scanner;

public class punto9 {
    double L1, L2, perimetro;
    Scanner cap;
    
    punto9()
    {
        cap = new Scanner(System.in);
    }
    
    void calculo_peri()
    {
        System.out.println("Ingrese el valor del lado 1: ");
        L1 = cap.nextDouble();
        System.out.println("Ingrese el valor del lado 2: ");
        L2 = cap.nextDouble();
        
        perimetro = 2 * (L1 + L2);
        
        System.out.printf("El perimetro del rectangulo es: %.1f%n", perimetro);
    }
}
