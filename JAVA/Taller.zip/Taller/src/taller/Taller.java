package taller;

import java.util.Scanner;

public class Taller {

  
    public static void main(String[] args) {
        Scanner cap = new Scanner(System.in);
        System.out.println("Ingrese un ejercicio del 1-16");
        int opcion = cap.nextInt();
        if (opcion == 1)
        {
            punto1 p1=new punto1();
            p1.incremento();
        }else if (opcion == 2)
        {
            punto2 p2=new punto2();
            p2.total();
        }else if (opcion == 3)
        {
            punto3 p3=new punto3();
            p3.operaciones();
        }else if (opcion == 4)
        {
            punto4 p4=new punto4();
            p4.determinante();
        }else if (opcion == 5)
        {
            punto5 p5=new punto5();
            p5.intercambio();
        }else if (opcion == 6)
        {
            punto6 p6=new punto6();
            p6.calculo_nota();
        }else if (opcion == 7)
        {
            punto7 p7=new punto7();
            p7.calculo_cono();
        }else if (opcion == 8)
        {
            punto8 p8=new punto8();
            p8.porcentajes();
        }else if (opcion == 9)
        {
            punto9 p9=new punto9();
            p9.calculo_peri();
        }else if (opcion == 10)
        {
            punto10 p10=new punto10();
            p10.conversion();
        }else if (opcion == 11)
        {
            punto11 p11=new punto11();
            p11.inversion();
        }else if (opcion == 12)
        {
            punto12 p12=new punto12();
            p12.compra_casa();
        }else if (opcion == 13)
        {
            punto13 p13=new punto13();
            p13.total_vendido();
        }else if (opcion == 14)
        {
            punto14 p14=new punto14();
            p14.calculo_porcentaje();
        }else if (opcion == 15)
        {
            punto15 p15=new punto15();
            p15.invertir();
        }else if (opcion == 16)
        {
            punto16 p16=new punto16();
            p16.nota_estudiante();
        }
        else{
            System.out.println("Opcion no valida");
        }
        
       
        
        
       
    }
    
}
