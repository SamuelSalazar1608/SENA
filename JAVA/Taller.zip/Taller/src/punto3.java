package taller;
//Lea dos números e imprima la suma, el producto, la diferencia y el cociente de los dos números.

import java.util.Scanner;

public class punto3 {
    double num1, num2, suma,multi,resta,div;
    Scanner cap;
    punto3()
    {
        cap = new Scanner(System.in);
        suma=0;
        multi=0;
        resta=0;
        div=0;
    }
    void operaciones()
    {
        System.out.println("Ingrese el primer numero; ");
        num1 = cap.nextInt();
        System.out.println("Ingrese el segundo numero; ");
        num2 = cap.nextInt();
        suma = num1 + num2;
        multi = num1 * num2;
        resta = num1 - num2;
        div = num1 / num2;
       
        System.out.println("La suma es: " + suma + 
                           ", La multiplicacion es: " + multi +
                           ", La resta es: " + resta + 
                           ", La division es: " + div);
    }
}
