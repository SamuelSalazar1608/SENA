package taller;
//Pida el precio de un artículo y calcule su valor aplicándole un incremento del 19% de IVA.

import java.util.Scanner;


public class punto1 {
    int articulo; 
    double valor;
    Scanner cap;
    punto1()
    {
        cap = new Scanner(System.in);
        valor = 0;
    }
    void incremento()
    {
        System.out.println("Ingrese el precio del articulo: ");
        articulo = cap.nextInt();
        valor = articulo + (articulo * 0.19);
        System.out.println("El valor total es de: "+ valor);
    }
    
}

