package taller;
/*
Calcule la nota definitiva de un estudiante para la asignatura Lógica de Programación I, teniendo
en cuenta que el examen parcial vale un 20%, el examen final vale un 20% y el seguimiento que
vale un 60% corresponde al promedio entre las notas de dos quices, un taller y un proyecto.
*/

import java.util.Scanner;

public class punto6 {
    double parcial, examen, seguimiento,quiz1, quiz2, taller, proyecto, nota_def;
    Scanner cap;
    
    punto6()
    {
        cap = new Scanner(System.in);
        nota_def = 0;
    }
    
    void calculo_nota()
    {
        System.out.println("Ingrese la nota del parcial: ");
        parcial = cap.nextDouble();
        System.out.println("Ingrese la nota del examen final: ");
        examen = cap.nextDouble();
        System.out.println("ingrese la nota del Quiz 1: ");
        quiz1 = cap.nextDouble();
        System.out.println("ingrese la nota del Quiz 2: ");
        quiz2 = cap.nextDouble();
        System.out.println("ingrese la nota del taller: ");
        taller = cap.nextDouble();
        System.out.println("ingrese la nota del proyecto: ");
        proyecto = cap.nextDouble();
        
        seguimiento = (quiz1 + quiz2 + taller + proyecto) / 4;
        nota_def = (parcial * 0.2) + (examen * 0.2) + (seguimiento * 0.6);
        
        System.out.printf("La nota definitiva es: %.1f%n", nota_def);

        
        if (nota_def >= 3.5){
            System.out.println("Aprobaste");
        }else{
            System.out.println("No aprobaste");
        }
            
        
        
    }
}
