package taller;
/*
Pida el valor de una casa, calcule el valor de la cuota inicial y el valor restante que debe prestar
al banco. La cuota inicial corresponde al 20% del valor de la casa. Determine además el valor
mensual a pagar de cuota inicial, dado que esta se puede cancelar en 24 cuotas iguales.
*/

import java.util.Scanner;


public class punto12 {
    double casa, cuota_ini, cuota_mensual, restante;
    Scanner cap;
    
    punto12()
    {
        cap = new Scanner(System.in);
        casa = 0;
    }
    
    void compra_casa()
    {
        System.out.println("Cual es el valor de la casa: ");
        casa = cap.nextDouble();
        
        cuota_ini = casa * 0.2;
        restante = casa - cuota_ini;
        cuota_mensual = cuota_ini / 24;
        
        System.out.println("El valor de la cuota inicial es de: " + cuota_ini);
        System.out.println("El valor que debe prestar al banco es: " + restante);
        System.out.printf("El valor mensual a pagar de la cuota inicial es de: %.1f%n", cuota_mensual);
        
    }
}


