package taller;
/*
Un restaurante de comidas rápidas ofrece los siguientes combos:
Combo 1: Hamburguesa, papas y gaseosa por valor de $10000
Combos 2: Perro y gaseosa por valor de $7000
Combo 3: Tacos y gaseosa por valor de $8000
Determine el valor total vendido por el restaurante en un día a partir de la cantidad de combos
vendidos de cada tipo.
*/

import java.util.Scanner;


public class punto13 {
    double combo1, combo2, combo3, total;
    int cant1, cant2, cant3;
    Scanner cap;
    
    punto13()
    {
        cap = new Scanner(System.in);
        combo1 = 10000;
        combo2 = 7000;
        combo3 = 8000;
               
    }
    
    void total_vendido()
    {
        System.out.println("Ingrese la cantidad de combos 1 vendidos: ");
        cant1 = cap.nextInt();
        System.out.println("Ingrese la cantidad de combos 2 vendidos: ");
        cant2 = cap.nextInt();
        System.out.println("Ingrese la cantidad de combos 3 vendidos: ");
        cant3 = cap.nextInt();
        
        total = (cant1 * combo1) + (cant2 * combo2) + (cant3 * combo3);
        
        System.out.printf("El valor total vendido por el restaurante es: %.1f%n ", total);
    }
}
