package taller;
/*
Calcule la nota definitiva de un estudiante a partir de la nota del examen parcial que
corresponde a un 20%, la nota del examen final que también corresponde a un 20% y la nota
del seguimiento que corresponde a un 60% de la asignatura.
*/
import java.util.Scanner;

public class punto16 {
    double definitiva,parcial,examen,seguimiento;
    Scanner cap;
    
    punto16()
    {
        cap = new Scanner(System.in);
    }
    
    void nota_estudiante()
    {
        System.out.println("Ingrese la nota del parcial: ");
        parcial = cap.nextDouble();
        System.out.println("Ingrese la nota del examen: ");
        examen = cap.nextDouble();
        System.out.println("Ingrese la nota del seguimiento: ");
        seguimiento = cap.nextDouble();
        
        definitiva = (parcial * 0.2) + (examen * 0.2) + (seguimiento * 0.6);
        
        System.out.printf("La nota definitiva del estudiante es: %.1f%n", definitiva);
    }
    
    
}
