package taller;
//Calcule el porcentaje de estudiantes mujeres y el porcentaje de estudiantes hombres de un salón de clases.

import java.util.Scanner;


public class punto8 {
    double mujeres, hombres, total, porcentaje_muj, porcentaje_hom;
    Scanner cap;
    
    punto8()
    {
        cap = new Scanner(System.in);
        
    }
    
    void porcentajes()
    {
        System.out.println("Ingrese la cantidad de estudiantes mujeres: ");
        mujeres = cap.nextDouble();
        System.out.println("Ingrese la cantidad de estudiantes hombres: ");
        hombres = cap.nextDouble();
        
        total = mujeres + hombres;
        porcentaje_muj = (mujeres / total) * 100;
        porcentaje_hom = (hombres / total) * 100;
        
        System.out.printf("el porcentaje de mujeres es: %.1f%%%n ", porcentaje_muj);
        System.out.printf("el porcentaje de hombres es: %.1f%%%n ", porcentaje_hom);
        
    }
}
