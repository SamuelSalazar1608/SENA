package taller;
/*
Tres personas deciden invertir su dinero para fundar una empresa. Cada una de ellas invierte
una cantidad distinta. Obtener el porcentaje que cada quien invierte con respecto a la cantidad
total invertida.
*/

import java.util.Scanner;


public class punto14 {
    double p1,p2,p3,porc1,porc2,porc3,total;
    Scanner cap;
    
    punto14()
    {
        cap = new Scanner(System.in);
    }
    
    void calculo_porcentaje()
    {
        System.out.println("Ingrese la inversion de la persona 1: ");
        p1 = cap.nextDouble();
        System.out.println("Ingrese la inversion de la persona 2: ");
        p2 = cap.nextDouble();
        System.out.println("Ingrese la inversion de la persona 3: ");
        p3 = cap.nextDouble();
        
        total = p1 + p2 + p3;
        porc1 = (p1 / total)* 100;
        porc2 = (p2 / total)* 100;
        porc3 = (p3 / total)* 100;
        
        System.out.printf("El total invertido de la persona 1 es: %.1f%%%n", porc1);
        System.out.printf("El total invertido de la persona 2 es: %.1f%%%n", porc2);
        System.out.printf("El total invertido de la persona 3 es: %.1f%%%n", porc3);
        
        
        
        
             
        
    }
}
